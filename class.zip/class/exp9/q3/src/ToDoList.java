import javax.swing.*;
import java.awt.*;

public class ToDoList extends JFrame {
    String[] list;
    String toDO="";
    ToDoList(){
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("To Do List");
        this.setSize(320,420);
        this.setResizable(true);
        this.setLocationRelativeTo(null);

        JTextField textField=new JTextField();
        textField.setText(toDO);
        textField.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        textField.setPreferredSize(new Dimension(0,50));
        textField.setPreferredSize(new Dimension(220,40));
        JButton button = new JButton("Add");
        button.setPreferredSize(new Dimension(30,20));

        JPanel topPanel = new JPanel();
        topPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT,10,10));
        topPanel.add(textField);
        topPanel.add(button);


        JList<String> jList = new JList<>();
        //jList.setListData(list);
        jList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        JPanel panel = new JPanel();
        panel.add(textField,JPanel.TOP_ALIGNMENT);
        panel.add(button,JPanel.RIGHT_ALIGNMENT);
        panel.add(jList,JPanel.BOTTOM_ALIGNMENT);
        JScrollPane scrollPane = new JScrollPane(panel);
        this.add(scrollPane);
    }

    public static void main(String[] arg){
        SwingUtilities.invokeLater(()->{
            new ToDoList().setVisible(true);
        });
    }
}
