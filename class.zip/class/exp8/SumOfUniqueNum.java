import java.util.*;
public class SumOfUniqueNum {
    public static void main(String[] arg){
        ArrayList<Integer> num = new ArrayList<Integer>(Arrays.asList(1,4,7,8,4,1,1,9,2));
        HashSet<Integer> nums = new HashSet<Integer>(num);
        int sum=0;
        for(int n: nums){
            sum+=n;
        }
        System.out.println(sum);
    }
}
